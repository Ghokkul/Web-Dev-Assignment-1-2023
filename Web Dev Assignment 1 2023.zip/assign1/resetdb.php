<!-- 
    Author: Ghokkul Muhunthan
    Student ID: 19079077
    Email: fyf3310@autuni.ac.nz

    Description of File: When you click the DropTable button it drops the table.
 -->
 
<?php
$servername = "localhost";
$username =  ""; 	
$password =  "";
$dbname = "fyf3310";


// Create connection 
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// sql to drop table
$delete = mysql_query("DROP TABLE StatusSystem");

if($delete !== FALSE)
{
   echo("Table has been deleted.");
}else{
   echo("Table has not been deleted.");
}
$conn->close();